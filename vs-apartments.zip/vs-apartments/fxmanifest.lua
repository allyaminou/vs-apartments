fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Europea'
description 'Apartment script'

version '1.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    '@es_extended/locale.lua',
    'client.lua',
    'locales/en.lua',
    'locales/nl.lua',
}

server_scripts {
    '@es_extended/locale.lua',
    '@mysql-async/lib/MySQL.lua',
    'server.lua',
    'locales/en.lua',
    'locales/nl.lua',
}