ESX             = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local instances = {}
 
RegisterServerEvent("instance:set")
AddEventHandler("instance:set", function(set)
    print('[INSTANCES] Instances looked like this: ', json.encode(instances))
    local src = source
    local instanceSource = 0
    if set then
        if set == 0 then
            for k,v in pairs(instances) do
                for k2,v2 in pairs(v) do
                    if v2 == src then
                        table.remove(v, k2)
                        if #v == 0 then
                            instances[k] = nil
                        end
                    end
                end
            end
        end
        instanceSource = set
    else
        instanceSource = math.random(1, 1000)
        while instances[instanceSource] and #instances[instanceSource] >= 1 do
            instanceSource = math.random(1, 1000)
            Citizen.Wait(1)
        end
    end
    print(instanceSource)
    if instanceSource ~= 0 then
        if not instances[instanceSource] then
            instances[instanceSource] = {}
        end
        table.insert(instances[instanceSource], src)
    end
    SetPlayerRoutingBucket(src, instanceSource)
    print('[INSTANCES] Instances now looks like this: ', json.encode(instances))
end)
 
Namedinstances = {}

RegisterServerEvent("instance:setNamed")
AddEventHandler("instance:setNamed", function(setName)
    print('[INSTANCES] Named Instances looked like this: ', json.encode(Namedinstances))
    local src = source
    local instanceSource = nil
 
    if setName == 0 then
            for k,v in pairs(Namedinstances) do
                for k2,v2 in pairs(v.people) do
                    if v2 == src then
                        table.remove(v.people, k2)
                    end
                end
                if #v.people == 0 then
                    Namedinstances[k] = nil
                end
            end
        instanceSource = setName
    else
        for k,v in pairs(Namedinstances) do
            if v.name == setName then
                instanceSource = k
            end
        end
        if instanceSource == nil then
            instanceSource = math.random(1, 1000)
 
            while Namedinstances[instanceSource] and #Namedinstances[instanceSource] >= 1 do
                instanceSource = math.random(1, 1000)
                Citizen.Wait(1)
            end
        end
    end
    if instanceSource ~= 0 then
        if not Namedinstances[instanceSource] then
            Namedinstances[instanceSource] = {name = setName, people = {}}
        end
        table.insert(Namedinstances[instanceSource].people, src)
    end
    SetPlayerRoutingBucket(src, instanceSource)
    print('[INSTANCES] Named Instances now look like this: ', json.encode(Namedinstances))
end)

--------------
-- Checking --
--------------

lib.callback.register('vs-apartments:getApartments', function(source, apartment, coords)
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local SellPercentage = Config.SellPercentage
    local id = MySQL.scalar.await('SELECT id FROM owned_apartments WHERE owner = @owner AND apartment = @apartment', { ['@owner'] = xPlayer.identifier, ['@apartment'] = apartment })
    local expired = MySQL.scalar.await('SELECT expired FROM owned_apartments WHERE id = @id', {['@id'] = id})
    local renewDate = MySQL.scalar.await('SELECT renewDate FROM owned_apartments WHERE id = @id', {['@id'] = id})
    local buy_price = MySQL.scalar.await('SELECT buy_price FROM apartments WHERE name = @name', { ['@name'] = apartment })
    local rent_price = MySQL.scalar.await('SELECT rent_price FROM apartments WHERE name = @name', { ['@name'] = apartment })
    local rentLength = MySQL.scalar.await('SELECT rentLength FROM apartments WHERE name = @name', { ['@name'] = apartment })
    local ownership_type = MySQL.scalar.await('SELECT ownership_type FROM owned_apartments WHERE owner = @owner AND apartment = @apartment', { ['@owner'] = xPlayer.identifier, ['@apartment'] = apartment })
    if id ~= nil and expired == 0 then
        local renew = MySQL.scalar.await('SELECT renew FROM owned_apartments WHERE id = @id', {['@id'] = id})
        local data = {coords = coords, id = id, buy_price = buy_price, rent_price = rent_price, renewDate = renewDate, ownership_type = ownership_type, rentLength = rentLength}
        return data
    else
        local id = false
        local data = {coords = coords, id = id, buy_price = buy_price, rent_price = rent_price, renewDate = renewDate, ownership_type = ownership_type, rentLength = rentLength}
        return data
    end
end)

lib.callback.register('vs-apartments:checkApptOwnership', function(source, apartment, appt_id)
	local xPlayer = ESX.GetPlayerFromId(source)
	local _source = source

	local id = MySQL.scalar.await('SELECT id FROM owned_apartments WHERE owner = @owner AND apartment = @apartment', {['@owner'] = xPlayer.identifier,['@apartment'] = apartment})
    if id ~= nil then
        return true
    else
        local id2 = MySQL.scalar.await('SELECT id FROM apartment_keys WHERE appt_id = @appt_id AND player = @player', {['@appt_id'] = appt_id,['@player'] = xPlayer.identifier})
        if id2 ~= nil then
            return true
        end
    end
end)

-----------------------
-- Rent / Buy / Sell --
-----------------------

RegisterServerEvent("vs-apartments:purchaseApartment")
AddEventHandler("vs-apartments:purchaseApartment", function(apartment, currentApartmentLabel)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local Price = MySQL.scalar.await('SELECT buy_price FROM apartments WHERE name = @Name', {['@Name'] = apartment})
    local ownershipType = 'purchase'

    local balance

    balance = xPlayer.getAccount('bank').money

    if Price <= balance then
        local t = os.time()
        local date = os.date("%Y%m%d", t)
        local d = 0 -- Omdat het een aankoop is, is er geen huurperiode
        local renewDate = t + d * 24 * 60 * 60

        local oldLease = MySQL.scalar.await('SELECT id FROM owned_apartments WHERE apartment = @apartment AND owner = @owner', {['@apartment'] = apartment, ['@owner'] = xPlayer.identifier})

        if oldLease ~= nil then
            -- Handle vernieuwing van een bestaand appartement
            local lastPayment = MySQL.update.await('UPDATE owned_apartments SET lastPayment = @lastPayment WHERE id = @id', {['@id'] = oldLease, ['@lastPayment'] = tonumber(date)})
            local renewDateChange = MySQL.update.await('UPDATE owned_apartments SET renewDate = @renewDate WHERE id = @id', {['@id'] = oldLease, ['@renewDate'] = os.date("%Y%m%d", renewDate)})
            local renew = MySQL.update.await('UPDATE owned_apartments SET renew = @renew WHERE id = @id', {['@id'] = oldLease, ['@renew'] = tonumber(1)})
            local expired = MySQL.update.await('UPDATE owned_apartments SET expired = @expired WHERE id = @id', {['@id'] = oldLease, ['@expired'] = tonumber(0)})
        else
            -- Handle aankoop van een nieuw appartement
            MySQL.insert('INSERT INTO `owned_apartments` (`owner`, `lastPayment`, `renewDate`, `apartment`, `ownership_type`, `renew`, `expired`) VALUES (@owner, @lastPayment, @renewDate, @apartment, @ownershipType, 1, 0)', {
                ['@apartment'] = apartment,
                ['@lastPayment'] = os.date("%Y%m%d", t),
                ['@renewDate'] = os.date("%Y%m%d", renewDate),
                ['@owner'] = xPlayer.identifier,
                ['@ownershipType'] = ownershipType
            })

            print('Database gekocht')

            if Config.UseOxInventory then
                MySQL.scalar('SELECT id FROM owned_apartments WHERE apartment = @apartment AND owner = @owner', {['@apartment'] = apartment, ['@owner'] = xPlayer.identifier}, function(id)
                    if id then
                        exports.ox_inventory:RegisterStash((apartment..id.."Stash"), (apartment.." Stash - "..id), 50, 100000, id)
                    end
                end)
            end
        end

        xPlayer.removeAccountMoney('bank', Price)

        TriggerClientEvent("vs-apartments:notification", _source, _U('buy_appt_notify') .. Price, nil, "success")
    else
        TriggerClientEvent("vs-apartments:notification", _source , _U('not_enough_money'), nil, "error")
    end
end)

RegisterServerEvent("vs-apartments:rentApartment")
AddEventHandler("vs-apartments:rentApartment", function(apartment, currentApartmentLabel)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local Price = MySQL.scalar.await('SELECT rent_price FROM apartments WHERE name = @Name', {['@Name'] = apartment})
    local rentLength = MySQL.scalar.await('SELECT rentLength FROM apartments WHERE Name = @Name', {['@Name'] = apartment})
    local ownershipType = 'rent'

    local balance

    balance = xPlayer.getAccount('bank').money

    if Price <= balance then
        local t = os.time()
        local date = os.date("%Y%m%d", t)
        local d = rentLength
        local renewDate = t + d * 24 * 60 * 60

        local oldLease = MySQL.scalar.await('SELECT id FROM owned_apartments WHERE apartment = @apartment AND owner = @owner', {['@apartment'] = apartment, ['@owner'] = xPlayer.identifier})

        if oldLease ~= nil then
            -- Handle vernieuwing van een bestaand appartement
            local lastPayment = MySQL.update.await('UPDATE owned_apartments SET lastPayment = @lastPayment WHERE id = @id', {['@id'] = oldLease, ['@lastPayment'] = tonumber(date)})
            local renewDateChange = MySQL.update.await('UPDATE owned_apartments SET renewDate = @renewDate WHERE id = @id', {['@id'] = oldLease, ['@renewDate'] = os.date("%Y%m%d", renewDate)})
            local renew = MySQL.update.await('UPDATE owned_apartments SET renew = @renew WHERE id = @id', {['@id'] = oldLease, ['@renew'] = tonumber(1)})
            local expired = MySQL.update.await('UPDATE owned_apartments SET expired = @expired WHERE id = @id', {['@id'] = oldLease, ['@expired'] = tonumber(0)})
        else
            -- Handle aankoop van een nieuw appartement
            MySQL.insert('INSERT INTO `owned_apartments` (`owner`, `lastPayment`, `renewDate`, `apartment`, `ownership_type`, `renew`, `expired`) VALUES (@owner, @lastPayment, @renewDate, @apartment, @ownershipType, 1, 0)', {
                ['@apartment'] = apartment,
                ['@lastPayment'] = os.date("%Y%m%d", t),
                ['@renewDate'] = os.date("%Y%m%d", renewDate),
                ['@owner'] = xPlayer.identifier,
                ['@ownershipType'] = ownershipType
            })

            print('Database gekocht')

            if Config.UseOxInventory then
                MySQL.scalar('SELECT id FROM owned_apartments WHERE apartment = @apartment AND owner = @owner', {['@apartment'] = apartment, ['@owner'] = xPlayer.identifier}, function(id)
                    if id then
                        exports.ox_inventory:RegisterStash((apartment..id.."Stash"), (apartment.." Stash - "..id), 50, 100000, id)
                    end
                end)
            end
        end

        xPlayer.removeAccountMoney('bank', Price)

        TriggerClientEvent("vs-apartments:notification", _source, _U('rent_appt_notify') .. Price, nil, "success")
    else
        TriggerClientEvent("vs-apartments:notification", _source , _U('not_enough_money'), nil, "error")
    end
end)

RegisterServerEvent('vs-apartments:sellApartment')
AddEventHandler('vs-apartments:sellApartment', function(apartment, currentApartmentLabel)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    -- Retrieve apartment details from the database
    local apartmentData = MySQL.query.await('SELECT * FROM apartments WHERE name = @Name', {['@Name'] = apartment})
    
    if apartmentData[1] then
        -- Fetch the buy price of the apartment from the database
        local sellData = MySQL.scalar.await('SELECT buy_price FROM apartments WHERE name = @name', { ['@name'] = apartment })

        -- Add a percentage factor to the selling price
        local percentage = Config.SellPercentage
        local percentageFactor = percentage / 100
        local finalSellPrice = math.floor(sellData * (1 - percentageFactor))

        -- Remove the apartment from the owner's list in the database
        MySQL.update('DELETE FROM owned_apartments WHERE owner = @owner AND apartment = @apartment', {
            ['@owner'] = xPlayer.identifier,
            ['@apartment'] = apartment
        })

        xPlayer.addAccountMoney('bank', finalSellPrice)

        TriggerClientEvent("vs-apartments:notification", _source, _U('sell_appt_notify') .. finalSellPrice, nil, "success")
    else
        TriggerClientEvent("vs-apartments:notification", _source, _U('error_notify'), nil, "error")
    end
end)

RegisterServerEvent('vs-apartments:stopRent')
AddEventHandler('vs-apartments:stopRent', function(apartment, currentApartmentLabel)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local apartmentData = MySQL.query.await('SELECT * FROM apartments WHERE name = @Name', {['@Name'] = apartment})
    
    if apartmentData[1] then

        MySQL.update('DELETE FROM owned_apartments WHERE owner = @owner AND apartment = @apartment', {
            ['@owner'] = xPlayer.identifier,
            ['@apartment'] = apartment
        })

        TriggerClientEvent("vs-apartments:notification", _source, _U('stoprent_notify'), nil, "success")
    else
        TriggerClientEvent("vs-apartments:notification", _source, _U('error_notify'), nil, "error")
    end
end)

-------------
-- Updaten --
-------------

RegisterServerEvent("vs-apartments:updateLastApartment")
AddEventHandler("vs-apartments:updateLastApartment", function(last_property)
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    print('test')
    MySQL.update('UPDATE users SET last_property = @last_property WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier,
        ['@last_property'] = last_property
    }, function(id)
    end)
end)

-----------
-- Stash --
-----------

AddEventHandler('onServerResourceStart', function(resourceName)
    if Config.UseOxInventory then
        MySQL.query('SELECT * FROM owned_apartments ', function(apartments)
            for i=1, #apartments, 1 do
                exports.ox_inventory:RegisterStash((apartments[i].apartment..apartments[i].id.."Opslag"), (apartments[i].apartment.." Opslag - "..apartments[i].id), 50, 100000, apartments[i].id)
            end
        end)
    end
end)

RegisterServerEvent("vs-apartments:updateStashApartment")
AddEventHandler("vs-apartments:updateStashApartment", function()
    if Config.UseOxInventory then
        MySQL.query('SELECT * FROM owned_apartments ', function(apartments)
            for i=1, #apartments, 1 do
                exports.ox_inventory:RegisterStash((apartments[i].apartment..apartments[i].id.."Opslag"), (apartments[i].apartment.." - "..apartments[i].id), 50, 100000, apartments[i].id)
            end
        end)
    end
end)  

------------------
-- Rent Checken --
------------------

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        MySQL.query('SELECT * FROM owned_apartments', function(apartments)
            for i = 1, #apartments, 1 do
                local todaysDate = tonumber(os.date("%Y%m%d", os.time()))
                if todaysDate > apartments[i].renewDate then
                    if apartments[i].renew and apartments[i].ownership_type == "rent" then
                        local Price = MySQL.scalar.await('SELECT rent_price FROM apartments WHERE Name = @Name', { ['@Name'] = apartments[i].apartment })
                        local rentLength = MySQL.scalar.await('SELECT rentLength FROM apartments WHERE Name = @Name', { ['@Name'] = apartments[i].apartment })
                        local accounts = MySQL.scalar.await('SELECT accounts FROM users WHERE identifier = @identifier', { ['@identifier'] = apartments[i].owner })
                        accounts = json.decode(accounts)
                        local balance = accounts.bank

                        if Price <= balance then
                            local t = os.time()
                            local date = os.date("%Y%m%d", t)
                            local d = rentLength
                            local renewDate = t + d * 24 * 60 * 60
                            local lastPayment = MySQL.update.await('UPDATE owned_apartments SET lastPayment = @lastPayment WHERE id = @id', { ['@id'] = apartments[i].id, ['@lastPayment'] = tonumber(date) })
                            local renewDateChange = MySQL.update.await('UPDATE owned_apartments SET renewDate = @renewDate WHERE id = @id', { ['@id'] = apartments[i].id, ['@renewDate'] = os.date("%Y%m%d", renewDate) })
                            if lastPayment ~= nil and renewDateChange ~= nil then
                                accounts.bank = balance - Price
                                MySQL.update.await('UPDATE users SET accounts = @accounts WHERE identifier = @identifier', { ['@identifier'] = apartments[i].owner, ['@accounts'] = json.encode(accounts) })
                            end
                        else
                            MySQL.update('UPDATE owned_apartments SET expired = @expired WHERE id = @id', {
                                ['@id'] = apartments[i].id,
                                ['@expired'] = 1
                            }, function(id)
                            end)
                        end
                    else
                        MySQL.update('UPDATE owned_apartments SET expired = @expired WHERE id = @id', {
                            ['@id'] = apartments[i].id,
                            ['@expired'] = 1
                        }, function(id)
                        end)
                    end
                end
            end
        end)
    end
end)
