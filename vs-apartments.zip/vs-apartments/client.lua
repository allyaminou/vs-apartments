local state = nil
local visible = false
local passedCheck = false
local checkOwnership = true
local AtStash = false
local currentApartment = nil
local currentApartmentID = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:onPlayerLogout')
AddEventHandler('esx:onPlayerLogout', function()
    spot = nil
    state = nil
    visible = false
    passedCheck = false
    AtStash = false
    currentApartment = nil
    currentApartmentID = nil
end)

local function Blips(coords, type, label, job, blipOptions)
    if job then return end
    if blip == false then return end
    local blip = AddBlipForCoord(coords)
    SetBlipSprite(blip, blipOptions.sprite or 357)
    SetBlipScale(blip, blipOptions.scale or 0.8)
    SetBlipColour(blip, blipOptions.colour ~= nil and blipOptions.colour or type == 'car' and Config.BlipColors.Car or type == 'boat' and Config.BlipColors.Boat or Config.BlipColors.Aircraft)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Apartment")
    EndTextCommandSetBlipName(blip)
end

function comma_value(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function Split(s, delimiter)
    if s ~= nil then
        result = {};
        for match in (s..delimiter):gmatch("(.-)"..delimiter) do
            table.insert(result, match);
        end
        return result;
    end
end

function onEnter(self)
    local apartment = Split(self.name, " ")
    currentApartment = apartment[1]

    if self.type == "entrance" then
        
    elseif self.type == "wardrobe" then

    elseif self.type == "stash" then

    elseif self.type == "exit" then

    end
end

function onExit(self)
    checkOwnership = true
    lib.hideTextUI()
    Citizen.Wait(100)
    visible = false
    passedCheck = false

    if self.type == "entrance" then
        
    elseif self.type == "wardrobe" then

    elseif self.type == "stash" then

    elseif self.type == "exit" then

    end
end

function insideZone(self)
    if self.type == "entrance" then
        if not visible then
            visible = true
            lib.showTextUI(_U('apartment'), {icon = "fa-solid fa-building"})
        end
        if IsControlJustReleased(0, 54) then
            lib.callback('vs-apartments:getApartments', false, function(data)
                TriggerEvent('vs-apartments:apartmentMenu', apartments, data)
            end, currentApartment, self.tpCoords)
        end
    elseif self.type == "exit" then
        if not visible then
            visible = true
            lib.showTextUI(_U('apartment_exit'), {icon = "fa-solid fa-door-open"})
        end
        if IsControlJustReleased(0, 54) then
            local coords = Config.Apartments[currentApartment].exitPoint
            local exitingData = { enteringExiting = 'Verlaat', coords = { x = Config.Apartments[currentApartment].exitPoint.x, y = Config.Apartments[currentApartment].exitPoint.y, z = Config.Apartments[currentApartment].exitPoint.z, h = Config.Apartments[currentApartment].exitPoint.h } }
            TriggerEvent('vs-apartments:enterExitApartment', exitingData)
        end
    elseif self.type == "stash" then
        if Config.UseOxInventory then
            if checkOwnership then
                passedCheck = lib.callback.await('vs-apartments:checkApptOwnership', false, currentApartment, currentApartmentID)
            end
            if passedCheck then
                checkOwnership = false
                if not visible then
                    visible = true
                    lib.showTextUI(_U('apartment_stash'), {icon = "fa-solid fa-box-open"})
                end
                if IsControlJustReleased(0, 54) then
                    exports.ox_inventory:openInventory('stash', {id = (currentApartment..currentApartmentID.."Opslag"), owner = currentApartmentID})
                end
            end
        end
    elseif self.type == "wardrobe" then
        if checkOwnership then
            passedCheck = lib.callback.await('vs-apartments:checkApptOwnership', false, currentApartment, currentApartmentID)
        end
        if passedCheck then
            checkOwnership = false
            if not visible then
                visible = true
                lib.showTextUI(_U('apartment_wardrobe'), {icon = "fa-solid fa-shirt"})
            end
            if IsControlJustReleased(0, 54) then
                
            end
        end
    end
end




for k, v in pairs(Config.Apartments) do
    lib.zones.box({
        coords = vec3(v.entrance.x, v.entrance.y, v.entrance.z),
        size = vec3(3, 3, 3),
        rotation = v.entrance.h,
        debug = false,
        inside = insideZone,
        onEnter = onEnter,
        onExit = onExit,
        name = k.." Entrance",
        tpCoords = v.exit,
        type = "entrance",
    })
    if v.wardrobe ~= nil then
        lib.zones.box({
            coords = vec3(v.wardrobe.x, v.wardrobe.y, v.wardrobe.z),
            size = vec3(v.wardrobe.w, v.wardrobe.l, 4),
            rotation = v.wardrobe.h,
            debug = false,
            inside = insideZone,
            onEnter = onEnter,
            onExit = onExit,
            name = v.zone.name.." Wardrobe",
            type = "wardrobe",
        })
    end
    if v.stash ~= nil then
        lib.zones.box({
            coords = vec3(v.stash.x, v.stash.y, v.stash.z),
            size = vec3(3, 5.4, 4),
            rotation = v.stash.h,
            debug = false,
            inside = insideZone,
            onEnter = onEnter,
            onExit = onExit,
            name = v.zone.name.." Stash",
            type = "stash",
        })
    end
    lib.zones.box({
        coords = vec3(v.exit.x, v.exit.y, v.exit.z),
        size = vec3(3, 3, 3),
        rotation = v.exit.h,
        debug = false,
        inside = insideZone,
        onEnter = onEnter,
        onExit = onExit,
        name = v.zone.name.." Exit",
        tpCoords = v.entrance,
        type = "exit",
    })  

    if v.blip ~= false then
        Blips(vector3(v.entrance.x, v.entrance.y, v.entrance.z), v.type, v.label, v.job, v.blip)
    end
end


--------------------
-- Apartment Menu --
--------------------

RegisterNetEvent('vs-apartments:apartmentMenu')
AddEventHandler('vs-apartments:apartmentMenu', function(apartments, data)
    local options = {}

    if not data.id then
        options = {
            {
                title = _U('buy_title') .. Config.Apartments[currentApartment].label,
                description = "€"..data.buy_price,
                event = 'vs-apartments:purchaseApartment',
                args = {
                    currentApartment = currentApartment,
                    coords = data.coords,
                    id = data.id
                }
            },
            {
                title = _U('rent_title')..Config.Apartments[currentApartment].label,
                description = "€"..comma_value(data.rent_price).._U('rent_period')..data.rentLength,
                event = 'vs-apartments:rentApartment',
                args = {
                    currentApartment = currentApartment,
                    coords = data.coords,
                    id = data.id
                }
            },
            {
                title = _U('preview_title'),
                description = _U('preview_description'),
                event = 'vs-apartments:enterExitApartment',
                args = {
                    coords = data.coords,
                    enteringExiting = "Bekijken"
                }
            },
        }
    else
        if data.ownership_type == 'purchase' then
            options = {
                {
                title = _U('enterapartment_title')..data.id,
                description = _U('enterapartment_description'),
                event = 'vs-apartments:enterExitApartment',
                args = {
                    coords = Config.Apartments[currentApartment].exit,
                    enteringExiting = "Binnengaan",
                    id = data.id
                    }
                },
                {
                    title = _U('sell_apartment_title')..Config.Apartments[currentApartment].label,
                    description = _U('sell_apartment'),
                    event = 'vs-apartments:sellApartment',
                    args = {
                        currentApartment = currentApartment,
                        coords = data.coords,
                        id = data.id
                    }
                },
            }
        else 
            options = {
                {
                    title = _U('enterapartment_title')..data.id,
                    description = _U('enterapartment_description'),
                    event = 'vs-apartments:enterExitApartment',
                    args = {
                        coords = Config.Apartments[currentApartment].exit,
                        enteringExiting = "Binnengaan",
                        id = data.id
                        }
                    },
                {
                    title = _U('stoprent_title'),
                    description = _U('stoprent_description'),
                    event = 'vs-apartments:stopRent',
                    args = {
                        currentApartment = currentApartment,
                        coords = data.coords,
                        id = data.id
                    }
                },
            }
        end
    end

    lib.registerContext({
        id = 'vs-apartments:apartmentMenu',
        title = Config.Apartments[currentApartment].label,
        options = options
    })
    lib.showContext('vs-apartments:apartmentMenu')
end)



----------------
-- Rent / Buy --
----------------


RegisterNetEvent('vs-apartments:purchaseApartment')
AddEventHandler('vs-apartments:purchaseApartment', function (currentApartment)
    TriggerServerEvent('vs-apartments:purchaseApartment', currentApartment.currentApartment)
    Citizen.Wait(250)
    TriggerServerEvent('vs-apartments:getApartments', currentApartment.currentApartment, currentApartment.exit)
    TriggerServerEvent('vs-apartments:updateStashApartment')
end)

RegisterNetEvent('vs-apartments:rentApartment')
AddEventHandler('vs-apartments:rentApartment', function (currentApartment)
    TriggerServerEvent('vs-apartments:rentApartment', currentApartment.currentApartment)
    Citizen.Wait(250)
    TriggerServerEvent('vs-apartments:getApartments', currentApartment.currentApartment, currentApartment.exit)
    TriggerServerEvent('vs-apartments:updateStashApartment')
end)

RegisterNetEvent('vs-apartments:sellApartment')
AddEventHandler('vs-apartments:sellApartment', function (currentApartment)
    TriggerServerEvent('vs-apartments:sellApartment', currentApartment.currentApartment)
    Citizen.Wait(250)
    TriggerServerEvent('vs-apartments:getApartments', currentApartment.currentApartment, currentApartment.exit)
end)

RegisterNetEvent('vs-apartments:stopRent')
AddEventHandler('vs-apartments:stopRent', function (currentApartment)
    TriggerServerEvent('vs-apartments:stopRent', currentApartment.currentApartment)
    Citizen.Wait(250)
    TriggerServerEvent('vs-apartments:getApartments', currentApartment.currentApartment, currentApartment.exit)
end)

------------------
-- Enter / Exit --
------------------

RegisterNetEvent('vs-apartments:enterExitApartment')
AddEventHandler('vs-apartments:enterExitApartment', function(coords, enteringExiting)
    if coords.id ~= nil then
        currentApartmentID = coords.id
    end

    local player = PlayerPedId()

    PlaySoundFrontend(-1, "CLOSED", "MP_PROPERTIES_ELEVATOR_DOORS", 1)
    Citizen.Wait(500)
    PlaySoundFrontend(-1, "Hack_Success", "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0)
    Citizen.Wait(500)
    PlaySoundFrontend(-1, "OPENED", "MP_PROPERTIES_ELEVATOR_DOORS", 1)

    if coords.enteringExiting == "Binnengaan" then
        -- Betreden van het appartement
        TriggerServerEvent('instance:setNamed', currentApartment .. coords.id)
        TriggerServerEvent('vs-apartments:updateLastApartment', currentApartment .. " " .. coords.id)
        currentApartmentID = coords.id
        SetEntityCoords(player, coords.coords.x, coords.coords.y, coords.coords.z)
        SetEntityHeading(player, coords.coords.h)
    elseif coords.enteringExiting == "Verlaat" then
        if state == "Bekijken" then
            -- Verlaten van het appartement tijdens het bekijken
            TriggerServerEvent('instance:set', 0)
            TriggerServerEvent('vs-apartments:updateLastApartment', nil)
            SetEntityCoords(player, Config.Apartments[currentApartment].entrance.x, Config.Apartments[currentApartment].entrance.y, Config.Apartments[currentApartment].entrance.z)
            SetEntityHeading(player, Config.Apartments[currentApartment].entrance.h)
        else
            -- Normaal verlaten van het appartement
            TriggerServerEvent('instance:setNamed', 0)
            TriggerServerEvent('vs-apartments:updateLastApartment', nil)
            SetEntityCoords(player, coords.coords.x, coords.coords.y, coords.coords.z)
            SetEntityHeading(player, coords.coords.h)
        end
        state = nil
        currentApartment = nil
        currentApartmentID = nil
    elseif coords.enteringExiting == "Bekijken" then
        state = "Bekijken"
        TriggerServerEvent('instance:set')
        SetEntityCoords(player, coords.coords.x, coords.coords.y, coords.coords.z)
        SetEntityHeading(player, coords.coords.h)
    end

    lib.hideTextUI()
end)

RegisterNetEvent('vs-apartments:notification')
AddEventHandler('vs-apartments:notification', function (Notificationtitle, Notificationdescription, Notificationtype)
	lib.notify({
        title = Notificationtitle,
        description = Notificationdescription,
        status = Notificationtype
    })
end)